/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test.metier;

import appli.modele.metier.Categorie;
import java.text.SimpleDateFormat;
/**
 *
 * @author elven
 */
public class TestCategorie {
    public static void main(String[] args) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
        
        System.out.println("TestCategorie");
        
        Categorie uneCategorie = new Categorie("B500", "chef", 4500, "BNP Paribas", 500);        
        System.out.println(uneCategorie.toStringEtat());
    }
    
}
