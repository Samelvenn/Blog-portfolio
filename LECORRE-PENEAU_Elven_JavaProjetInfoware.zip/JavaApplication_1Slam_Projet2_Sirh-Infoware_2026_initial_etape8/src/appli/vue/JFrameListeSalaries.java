package appli.vue;

import appli.exceptions.ConnexionBDDException;
import appli.modele.dao.*;
import appli.modele.metier.*;
import appli.exceptions.ImageDefondNonTrouveeException;

import java.util.List;

import java.io.IOException;
import java.sql.SQLException;

import javax.swing.*;
import javax.swing.table.*;

/**
 * GUI liste des salariés par service Fenêtre principale de l'application
 *
 * @author btssio
 */

public class JFrameListeSalaries extends javax.swing.JFrame {

    /**
     * Salarié couramment sélectionné dans la JTable ou null si aucun
     */
    private Salarie leSalarieSelectionne = null;

    /**
     * les modèles de contenu pour le tableau des salariés et la liste des
     * services
     */
    private final DefaultTableModel modeleJTableLesSalaries;
    private DefaultComboBoxModel modeleJComboLesServices;
    
    
    /**
     * Creates new form JFrameListeSalariess
     * @param imageDeFond image d'arrière plan
     */
    public JFrameListeSalaries(String imageDeFond) {
        super();        
        // I- APPARENCE DE LA FENETRE
        //   I-1 - l'image de fond
        BackgroundPanel bgpnl;
        try {
           bgpnl = new BackgroundPanel(imageDeFond);
           this.setContentPane(bgpnl);
        } catch (ImageDefondNonTrouveeException ex) {
            JOptionPane.showMessageDialog(this, 
                                          "JFrameListeSalaries - Pb de chargement de l'image de fond : \n" + ex.getMessage(),  
                                          "Incident", 
                                          JOptionPane.WARNING_MESSAGE
            );
        }
         
        //   I-2- le design défini avec NetBeans
        initComponents();

        //   I-3 - le "look and feel"
        try {
            /**
             * apparence des vues Valeurs possibles : LaF : Metal :
             * javax.swing.plaf.metal.MetalLookAndFeel LaF : Nimbus :
             * javax.swing.plaf.nimbus.NimbusLookAndFeel LaF : CDE/Motif :
             * com.sun.java.swing.plaf.motif.MotifLookAndFeel LaF : GTK+ :
             * com.sun.java.swing.plaf.gtk.GTKLookAndFeel
             */
            javax.swing.UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
            System.getLogger(JFrameListeSalaries.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            JOptionPane.showMessageDialog(this, 
                                          "JFrameListeSalaries - Pb de chargement du Look&Feel : \n" + ex.getMessage(),  
                                          "Incident", 
                                          JOptionPane.ERROR_MESSAGE
            );
        }

        //   I-4 - le positionnement initial
        this.setLocationRelativeTo(null);
//        this.setLocation(150, 150);

        // II- AFFICHAGE DES DONNEES
        // II-1 Définition du nouveau modèle de JComboBox
        modeleJComboLesServices = new DefaultComboBoxModel();
        jComboBoxLesServices.setModel(modeleJComboLesServices);

        // II-2 Définition du nouveau modèle de JTable :
        //      II-2-a- rendre les cellules non éditables
        modeleJTableLesSalaries = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int iRowIndex, int iColumnIndex) {
                return false;
            }
        };
        //      II-2-b- affecter le modèle au composant JTable       
        jTableSalaries.setModel(modeleJTableLesSalaries);
        //      II-2-c- configurer les colonnes
        String[] titres = {"Code", "Nom", "Prenom", "Date naiss.", "Date emb.", "Fonction", "Service"};
        modeleJTableLesSalaries.setColumnIdentifiers(titres);
        //      II-2-d- adapter la largeur des colonnes
        jTableSalaries.getColumnModel().getColumn(0).setPreferredWidth(50);
        jTableSalaries.getColumnModel().getColumn(3).setPreferredWidth(90);
        jTableSalaries.getColumnModel().getColumn(4).setPreferredWidth(90);
        jTableSalaries.getColumnModel().getColumn(5).setPreferredWidth(150);
        jTableSalaries.getColumnModel().getColumn(6).setPreferredWidth(100);

    try {
            List<Service> lesServices = DaoService.getAll();
            this.remplirJComBoxServices(lesServices);
        } catch (IOException | SQLException | ConnexionBDDException ex) {
            JOptionPane.showMessageDialog(this, "Erreur de chargement des services" + ex.getMessage());
        }

        try {
            List<Salarie> lesSalaries = DaoSalarie.getAll();
            this.remplirJTableSalaries(lesSalaries);
        } catch (IOException | SQLException | ConnexionBDDException ex) {
            JOptionPane.showMessageDialog(this, "Erreur de chargement des salariés" + ex.getMessage());
        }

        jComboBoxLesServices.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxLesServicesActionPerformed(evt);
            }
        });
    
    }
    
      private void jComboBoxLesServicesActionPerformed(java.awt.event.ActionEvent evt) {
        Service serviceSelectionne = (Service) jComboBoxLesServices.getSelectedItem();

        if (serviceSelectionne == null) return;

        try {
            List<Salarie> lesSalaries;

            if (serviceSelectionne.getCode() == 0) {
                lesSalaries = DaoSalarie.getAll();
            } else {
                lesSalaries = DaoSalarie.getAllByService(serviceSelectionne.getCode());
            }
            remplirJTableSalaries(lesSalaries);
        } catch (IOException | SQLException | ConnexionBDDException ex) {
            JOptionPane.showMessageDialog(this, "Erreur au moment du filtrage par service" + ex.getMessage());
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableSalaries = new javax.swing.JTable();
        jComboBoxLesServices = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        jButtonQuitter = new javax.swing.JButton();
        jButtonSupprimer = new javax.swing.JButton();
        jButtonModifier = new javax.swing.JButton();
        jButtonAjouter = new javax.swing.JButton();
        jButtonConsulter = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("InfoWare - SIRH");

        jLabel1.setFont(new java.awt.Font("Adwaita Sans", 1, 16)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Liste des salariés par service");

        jTableSalaries.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTableSalaries.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableSalariesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableSalaries);

        jLabel2.setText("Service :");

        jButtonQuitter.setText("Quitter");
        jButtonQuitter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonQuitterActionPerformed(evt);
            }
        });

        jButtonSupprimer.setText("Supprimer");
        jButtonSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSupprimerActionPerformed(evt);
            }
        });

        jButtonModifier.setText("Modifier");

        jButtonAjouter.setText("Ajouter");
        jButtonAjouter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAjouterActionPerformed(evt);
            }
        });

        jButtonConsulter.setText("Consulter");
        jButtonConsulter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonConsulterActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jComboBoxLesServices, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(310, 310, 310))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 741, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jButtonConsulter)
                        .addGap(40, 40, 40)
                        .addComponent(jButtonAjouter)
                        .addGap(108, 108, 108)
                        .addComponent(jButtonModifier)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonSupprimer)
                        .addGap(99, 99, 99)
                        .addComponent(jButtonQuitter)))
                .addGap(26, 26, 26))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(241, 241, 241))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBoxLesServices, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(35, 35, 35)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonQuitter)
                    .addComponent(jButtonSupprimer)
                    .addComponent(jButtonModifier)
                    .addComponent(jButtonAjouter)
                    .addComponent(jButtonConsulter))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Gestionnaire d' événement : l'utilisateur a cliqué sur la table des salariés
     * @param evt événement responsable du déclenchement de ce handler
     */
    private void jTableSalariesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableSalariesMouseClicked
        // Un salarié est-il sélectionné ?
        if (jTableSalaries.getSelectedRow() > -1) {
            String codeSalarie = (String) jTableSalaries.getValueAt(jTableSalaries.getSelectedRow(), 0);
            // Lire le salarié sélectionné dans la BDD
            try {
                this.leSalarieSelectionne = DaoSalarie.getOneById(codeSalarie);
                System.out.println("Salarié sélexctionné :\n" + leSalarieSelectionne.toString());
            } catch (IOException | SQLException | ConnexionBDDException ex) {
                JOptionPane.showMessageDialog(this,
                        "JFrameListeSalaries - pb lecture salarie sélectionné : \n" + ex.getMessage(),
                        "Incident",
                        JOptionPane.ERROR_MESSAGE
                );
                ex.printStackTrace();
            }
        } else {
            this.leSalarieSelectionne = null;
        }

    }//GEN-LAST:event_jTableSalariesMouseClicked

 /**
 * Action en cas de clic sur le bouton quitter
 * @param evt 
 */
    private void jButtonQuitterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonQuitterActionPerformed
        this.dispose(); // libération de l'objet JFrame
        System.exit(0); // fin de l'exécution du programme
    }//GEN-LAST:event_jButtonQuitterActionPerformed

    private void jButtonConsulterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonConsulterActionPerformed
        //Récupération de l'index
        int index = jTableSalaries.getSelectedRow();

        //Vérification de la sélection (Condition de garde)
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un salarié !", "Attention", JOptionPane.WARNING_MESSAGE);
        }

        try {
            //Extraction de l'ID depuis la JTable (Modèle de données)
            String id = jTableSalaries.getValueAt(index, 0).toString();

            //Appel au DAO (Couche Accès aux Données)
            Salarie s = DaoSalarie.getOneById(id);

            //Passage à la vue suivante
            if (s != null) {
                JFrameProfil page = new JFrameProfil(s);
                page.setVisible(true);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erreur système : " + ex.getMessage());
        }


    }//GEN-LAST:event_jButtonConsulterActionPerformed

    private void jButtonSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSupprimerActionPerformed
        JFrameSupprimer page = new JFrameSupprimer();
        page.setVisible(true);
    }//GEN-LAST:event_jButtonSupprimerActionPerformed

    private void jButtonAjouterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAjouterActionPerformed
        JFrameAjouter page = new JFrameAjouter();
        page.setVisible(true);
    }//GEN-LAST:event_jButtonAjouterActionPerformed

    /**
     * Remplir la liste déroulante des noms de services
     * @param desServices collection d'objet de type Service à afficher
     */
    public void remplirJComBoxServices(List<Service> desServices) {
    modeleJComboLesServices.removeAllElements();
    // La première option permet de sélectionner tous les salariés
    modeleJComboLesServices.addElement(new Service(0, "*** Tous services ***"));
    // Options suivantes : une par service
    for (Service unService : desServices) {
        modeleJComboLesServices.addElement(unService);
    }
}

    /**
     * Remplir la table des salariés
     * @param desSalaries collection d'objets de type Salarie à afficher
     */
    public void remplirJTableSalaries(List<Salarie> desSalaries) {
    modeleJTableLesSalaries.setRowCount(0);
    // Une ligne de la table est un tableau d'objets
    Object[] rowData = new Object[jTableSalaries.getColumnModel().getColumnCount()];
    for (Salarie unSalarie : desSalaries) {
        rowData[0] = unSalarie.getCode();
        rowData[1] = unSalarie.getNom();
        rowData[2] = unSalarie.getPrenom();
        rowData[3] = unSalarie.getDateNaiss();
        rowData[4] = unSalarie.getDateEmbauche();
        rowData[5] = unSalarie.getFonction();
        if (unSalarie.getService() != null) {
            rowData[6] = unSalarie.getService().getDesignation();
        } else {
            rowData[6] = "";
        }

        modeleJTableLesSalaries.addRow(rowData);
    }
}
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAjouter;
    private javax.swing.JButton jButtonConsulter;
    private javax.swing.JButton jButtonModifier;
    private javax.swing.JButton jButtonQuitter;
    private javax.swing.JButton jButtonSupprimer;
    private javax.swing.JComboBox jComboBoxLesServices;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableSalaries;
    // End of variables declaration//GEN-END:variables
}
