/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appli.modele.dao;

import appli.exceptions.ConnexionBDDException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import appli.modele.metier.Categorie;
import java.io.FileNotFoundException;

/**
     * Rechercher un enregistrement dans la table CATEGORIE d'après son code (string)
     * et en faire un objet de type Categorie
     *
     * @throws SQLException
     * @throws java.io.IOException
     * @throws java.io.FileNotFoundException
     * @throws appli.exceptions.ConnexionBDDException
     */
public class DaoCategorie {
    public static Categorie getOneById(String id) throws SQLException, IOException, FileNotFoundException, ConnexionBDDException {
        Categorie categorieTrouve = null;
        Connection cnx = ConnexionBDD.getConnexion();
        PreparedStatement pstmt = cnx.prepareStatement("SELECT * FROM Categorie WHERE Code = ?");
        pstmt.setString(1, id);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            categorieTrouve = new Categorie(
                    id,
                    rs.getString("Libelle"),
                    rs.getDouble("salaireMini"),
                    rs.getString("CaisseDeRetraite"),
                    rs.getInt("PrimeResultat")
            );
        }
        return categorieTrouve;
    }
     /**
     * Extraire l'ensemble des enregistrements de la table CATEGORIE
     * @return liste d'objets de type Categorie
     * @throws SQLException 
     * @throws java.io.IOException 
     * @throws java.io.FileNotFoundException 
     * @throws appli.exceptions.ConnexionBDDException 
     */
    public static ArrayList<Categorie> getAll() throws SQLException, IOException, FileNotFoundException, ConnexionBDDException {
        ArrayList<Categorie> lesCategoriesTrouves = new ArrayList<>();
        Connection cnx = ConnexionBDD.getConnexion();
        PreparedStatement pstmt = cnx.prepareStatement("SELECT * FROM Categorie");
        ResultSet rs = pstmt.executeQuery();
        while (rs.next()) {
            Categorie uneCategorie = new Categorie(
                    rs.getString("Code"),
                    rs.getString("Libelle"),
                    rs.getDouble("salaireMini"),
                    rs.getString("CaisseDeRetraite"),
                    rs.getInt("PrimeResultat")
            );
            lesCategoriesTrouves.add(uneCategorie);
        }
        return lesCategoriesTrouves;
    }
}
