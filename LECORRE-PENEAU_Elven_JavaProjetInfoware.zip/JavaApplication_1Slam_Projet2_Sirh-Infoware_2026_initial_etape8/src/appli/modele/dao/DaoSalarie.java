package appli.modele.dao;

import appli.exceptions.ConnexionBDDException;
import appli.modele.metier.*;
import java.io.FileNotFoundException;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe DAO : liaison classe métier Salarie / table SALARIE
 *
 * @author btssio
 */
public class DaoSalarie {

    /**
     * Rechercher un enregistrement dans la table SALARIE d'après son code
     * (String) et en faire un objet de type Salarie
     *
     * @param id code du salarie recherché
     * @return objet de type Salarie si trouvé dans la BDD, null sinon
     * @throws SQLException
     * @throws java.io.IOException
     * @throws appli.exceptions.ConnexionBDDException
     */
    public static Salarie getOneById(String id) throws SQLException, IOException, ConnexionBDDException {
        Salarie salarieTrouve = null;
        Connection cnx = ConnexionBDD.getConnexion();
        PreparedStatement pstmt = cnx.prepareStatement("SELECT * FROM Salarie WHERE Code = ?");
        pstmt.setString(1, id);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            salarieTrouve = creerSalarie(rs);
        }
        return salarieTrouve;
    }

    /**
     * Extraire l'ensemble des enregistrements de la table SALARIE
     *
     * @return liste d'objets de type Salarie
     * @throws SQLException
     * @throws java.io.IOException
     * @throws java.io.FileNotFoundException
     * @throws appli.exceptions.ConnexionBDDException
     */
    public static ArrayList<Salarie> getAll() throws SQLException, IOException, FileNotFoundException, ConnexionBDDException {
        ArrayList<Salarie> lesSalariesTrouves = new ArrayList<>();
        Connection cnx = ConnexionBDD.getConnexion();
        PreparedStatement pstmt = cnx.prepareStatement("SELECT * FROM Salarie");
        ResultSet rs = pstmt.executeQuery();
        while (rs.next()) {
            Salarie unSalarie = creerSalarie(rs);
            lesSalariesTrouves.add(unSalarie);
        }
        return lesSalariesTrouves;
    }

    /**
     * Transforme un enregistrement de la table SALARIE en instance de Salarie
     *
     * @param rs jeu d'enregistrements ; l'enregistrement courant est concerné
     * @return instance de Salarie
     * @throws SQLException
     * @throws IOException
     */
    private static Salarie creerSalarie(ResultSet rs) throws SQLException, IOException, FileNotFoundException, ConnexionBDDException {
        Salarie unSalarie = null;
        // Récupération du service du salarié
        Service unService = DaoService.getOneById(rs.getInt("CodeServ"));
        // Récupération de la categorie du salarié
        Categorie uneCategorie = DaoCategorie.getOneById(rs.getString("NumCat"));
        unSalarie = new Salarie(
                rs.getString("Code"),
                rs.getString("Nom"),
                rs.getString("Prenom"),
                (java.util.Date) rs.getDate("DateNaiss"),
                (java.util.Date) rs.getDate("DateEmbauche"),
                rs.getString("Fonction"),
                rs.getDouble("TauxHoraire"),
                rs.getString("situationFamiliale"),
                rs.getInt("NbrEnfants"),
                unService,
                uneCategorie
        );
        return unSalarie;
    }
    
    public static List<Salarie> getAllByService(int codeService) throws IOException, SQLException, ConnexionBDDException {
        List<Salarie> lesSalaries = new ArrayList<>();
        Connection cnx = ConnexionBDD.getConnexion();

        String sql = "SELECT * FROM Salarie WHERE CodeServ = ?";
        PreparedStatement pstmt = cnx.prepareStatement(sql);
        pstmt.setInt(1, codeService);
        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            lesSalaries.add(creerSalarie(rs));
        }
        rs.close();
        pstmt.close();
        return lesSalaries;
    }
    
    public static void ajouter_salarie(Salarie s) throws SQLException, IOException, FileNotFoundException, ConnexionBDDException {
        String requete = "INSERT INTO Salarie (Code, Nom, Prenom, DateNaiss, DateEmbauche, Fonction, TauxHoraire, situationFamiliale, NbrEnfants, NumCat, CodeServ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        Connection cnx = ConnexionBDD.getConnexion();
        PreparedStatement pstmt = cnx.prepareStatement(requete);
        pstmt.setString(1, s.getCode());
        pstmt.setString(2, s.getNom());
        pstmt.setString(3, s.getPrenom());
        pstmt.setDate(4, new java.sql.Date(s.getDateNaiss().getTime()));
        pstmt.setDate(5, new java.sql.Date(s.getDateEmbauche().getTime()));
        pstmt.setString(6, s.getFonction());
        pstmt.setDouble(7, s.getTauxHoraire());
        pstmt.setString(8, s.getSituationFamiliale());
        pstmt.setInt(9, s.getNbrEnfants());
        pstmt.setString(10, s.getCategorie().getCode());
        pstmt.setInt(11, s.getService().getCode());
        pstmt.executeUpdate();
        
    }

}
