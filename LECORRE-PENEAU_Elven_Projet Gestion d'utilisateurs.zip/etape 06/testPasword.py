import csv

#Contraintes
majuscule="ABCDEFGHJKLMNPQRSTUVWXYZ"
minuscule="abcdefghijklmnpqrstuvwxyz"
chiffre="123456789"
caractere_spe="!@#$%&*+-=.<>/?:"


def verifier_mdp(mdp):
    nb_maj=0
    nb_min=0
    nb_chiffre=0
    nb_cara=0
    #Test Longueur minimale
    if len(mdp) < 12:
        return "Le mot de passe est trop cours"

    #Test si il y a des caractères interdits
    if " " in mdp:
        return "Contient un espace"
    if "O" in mdp:
        return "Contient la lettre O"
    if "0" in mdp:
        return "Contient le chiffre 0"

    #Test si il y a le bon nombre minimum de chaque élément
    for i in mdp:
        if i in majuscule:
            nb_maj+=1
        if i in minuscule:
            nb_min+=1
        if i in chiffre:
            nb_chiffre+=1
        if i in caractere_spe:
            nb_cara+=1
    
    if nb_maj < 2:
        return "Pas assez de majuscules (min 2)"
    if nb_min < 2:
        return "Pas assez de minuscules (min 2)"
    if nb_chiffre < 2:
        return "Pas assez de chiffres (min 2)"
    if nb_cara < 2:
        return "Pas assez de caractères spéciaux (min 2)"

    #Test si il n'y a pas de caractere spéciale au début ou à la fin
    if mdp[0] in caractere_spe:
        return "Caractère spécial en début (interdit)"
    if mdp[-1] in caractere_spe:
        return "Caractère spécial en fin (interdit)"

    return "Valide"

#Programme qui permet de vérifier l'ensemble des mots de passe 
with open("C:/Users/elven/OneDrive - Ogec la Joliverie/Projet inter semestre/etape 06/usersPassword2.csv", "r", encoding="utf-8") as fichier_mdp:
    lecteur = csv.reader(fichier_mdp)
    next(lecteur)  # ignorer l'en-tête(password)

    deja_vus = []
    doublons = 0

    for ligne in lecteur:
        mdp = ligne[0]

        # Vérification du mot de passe
        resultat = verifier_mdp(mdp)
        print(resultat)

        # Vérification des doublons
        if mdp in deja_vus:
            doublons+=1
        else:
            deja_vus.append(mdp)

# Affichage des doublons
if doublons >0:
    print("⚠ Doublons détectés ")
else:
    print("Aucun doublon détecté.")

