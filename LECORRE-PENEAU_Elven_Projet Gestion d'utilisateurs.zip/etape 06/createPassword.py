import csv 
import random

#Initialisation des variables pour pouvoir réaliser le mot de passe. 
mdp_final=[]
majuscule="ABCDEFGHJKLMNPQRSTUVWXYZ"
minuscule="abcdefghijklmnpqrstuvwxyz"
chiffre="123456789"
caractere_spe="!@#$%&*+-=.<>/?:"
tout_caractere= majuscule+minuscule+chiffre+caractere_spe
    
#Fonction qui créer les mots de passes 
def creation_mdp():
    mdp_final=[random.choice(majuscule),random.choice(minuscule),random.choice(chiffre),random.choice(caractere_spe),random.choice(majuscule),random.choice(minuscule),random.choice(chiffre),random.choice(caractere_spe)]
    while len(mdp_final) < 12:
        mdp_final.append(random.choice(tout_caractere))

    #Mélanger le mot de passe 
    random.shuffle(mdp_final)

    #Remélange le mot de passe pour éviter d'avoir un caractère spécial en première et dernière position
    while mdp_final[0] in caractere_spe or mdp_final[-1] in caractere_spe:
        random.shuffle(mdp_final)

    return ''.join(mdp_final)
    
nb_mdp=int(input("Combien de mots de passe voulez-vous générer ?"))
        
with open("usersPassword2.csv", "w",encoding="utf-8", newline="") as sortie:
    liste_mdp=csv.writer(sortie, delimiter=",")

    # Écriture de l'en-tête
    liste_mdp.writerow(["password"])

    #Générer le nombre de mots de passe voulu
    for _ in range(nb_mdp):
        liste_mdp.writerow([creation_mdp()])
    


