import csv

#code repris de loginNormaliser

def normaliser_prenom(prenom):
    prenom = prenom.replace("-", " ")
    parties = prenom.split(" ")

    initiales = ""
    for p in parties:
        if p != "":
            initiales += p[0]

    return initiales.lower()


def normaliser_nom(nom):
    nom = nom.lower()

    # Suppression des accents (manuellement)
    nom = nom.replace("é", "e").replace("è", "e").replace("ê", "e").replace("ë", "e")
    nom = nom.replace("à", "a").replace("â", "a")
    nom = nom.replace("î", "i").replace("ï", "i")
    nom = nom.replace("ô", "o")
    nom = nom.replace("ù", "u").replace("û", "u")
    nom = nom.replace("ç", "c")
    nom = nom.replace("í", "i").replace("ó", "o").replace("á", "a")
    nom = nom.replace("ñ", "n")

    # Suppression espaces, apostrophes et tirets
    nom = nom.replace(" ", "")
    nom = nom.replace("-", "")
    nom = nom.replace("'", "")
    nom = nom.replace("’", "")

    return nom


#Lecture des fichiers

#Lecture des utilisateurs
users = []
with open("C:/Users/elven/OneDrive - Ogec la Joliverie/Projet inter semestre/etape 05/usersToulouse.csv", "r", encoding="utf-8") as f:
    lecteur = csv.reader(f, delimiter=";")
    next(lecteur)  # ignorer l'en-tête

    for ligne in lecteur:
        firstname = ligne[0]
        lastname = ligne[1]
        users.append((firstname, lastname))

#Lecture des mots de passe
passwords = []
with open("C:/Users/elven/OneDrive - Ogec la Joliverie/Projet inter semestre/etape 06/usersPassword2.csv", "r", encoding="utf-8") as f:
    lecteur = csv.reader(f, delimiter=",")
    next(lecteur)  # ignorer l'en-tête

    for ligne in lecteur:
        passwords.append(ligne[0])

    print("Nb users     :", len(users))
    print("Nb passwords :", len(passwords))

    if len(users) != len(passwords):
        print("Erreur : le nombre d'utilisateurs ne correspond pas au nombre de mots de passe.")
        exit()

#Création du fichier csv

with open("loginToulouse.csv", "w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f, delimiter=";")
    writer.writerow(["login", "password", "lastname", "firstname"])

    for i in range(len(users)):
        firstname, lastname = users[i]
        password = passwords[i]

        # Normalisation avec TON code
        initiales = normaliser_prenom(firstname)
        nom_norm = normaliser_nom(lastname)

        # Login = initiales + nom normalisé
        login = initiales + nom_norm

        writer.writerow([login, password, lastname, firstname])


