import csv

with open("C:/Users/elven/Desktop/Cours/Projet inter semestre/etape 03/testEntreeSpeciaux.csv", "r", encoding="utf-8") as entree, \
     open("testSortieSpeciaux.csv", "w", encoding="utf-8", newline="") as sortie:

    lecteur = csv.reader(entree, delimiter=";")
    ecrivain = csv.writer(sortie, delimiter=";")

    # Écriture de l'en-tête
    ecrivain.writerow(["login"])

    # Ignorer l'en-tête du fichier d'entrée
    next(lecteur)

    for ligne in lecteur:
        prenom = ligne[0]
        nom = ligne[1]

        #Normalisation du prénom
        prenom = prenom.replace("-", " ")
        parties = prenom.split(" ")

        initiales = ""
        for p in parties:
            if p != "":
                initiales += p[0]

        initiales = initiales.lower()

        #Normalisation du nom
        nom = nom.lower()

        # Suppression des accents
        nom = nom.replace("é", "e").replace("è", "e").replace("ê", "e").replace("ë", "e")
        nom = nom.replace("à", "a").replace("â", "a")
        nom = nom.replace("î", "i").replace("ï", "i")
        nom = nom.replace("ô", "o")
        nom = nom.replace("ù", "u").replace("û", "u")
        nom = nom.replace("ç", "c")
        nom = nom.replace("í", "i").replace("ó", "o").replace("á", "a")
        nom = nom.replace("ñ", "n")

        # Suppression espaces, apostrophes et tirets
        nom = nom.replace(" ", "")
        nom = nom.replace("-", "")
        nom = nom.replace("'", "")
        nom = nom.replace("’", "")

        #Génération du login
        login = initiales + nom

        ecrivain.writerow([login])
