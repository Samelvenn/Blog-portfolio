-- Suppression : givenName sn
DROP DATABASE st_gsn;
DROP USER 'gsn'@'%';
FLUSH PRIVILEGES;

-- Suppression : Charlotte RUIZ
DROP DATABASE st_cruiz;
DROP USER 'cruiz'@'%';
FLUSH PRIVILEGES;

-- Suppression : Noemie SAMSON
DROP DATABASE st_nsamson;
DROP USER 'nsamson'@'%';
FLUSH PRIVILEGES;

-- Suppression : Myrtille BONHOMME
DROP DATABASE st_mbonhomme;
DROP USER 'mbonhomme'@'%';
FLUSH PRIVILEGES;

-- Suppression : Arthur LELEU
DROP DATABASE st_aleleu;
DROP USER 'aleleu'@'%';
FLUSH PRIVILEGES;

-- Suppression : Emilie BRIERE
DROP DATABASE st_ebriere;
DROP USER 'ebriere'@'%';
FLUSH PRIVILEGES;

-- Suppression : Charlotte AUVRAY
DROP DATABASE st_cauvray;
DROP USER 'cauvray'@'%';
FLUSH PRIVILEGES;

-- Suppression : Noemie PAGE
DROP DATABASE st_npage;
DROP USER 'npage'@'%';
FLUSH PRIVILEGES;

