-- Utilisateur : givenName sn
CREATE USER 'gsn'@'%' IDENTIFIED BY 'U3AJ/+1zC!?e';
CREATE DATABASE st_gsn;
GRANT ALL PRIVILEGES ON st_gsn.* TO 'gsn'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Charlotte RUIZ
CREATE USER 'cruiz'@'%' IDENTIFIED BY 'x&L7Fb/%Vp<5';
CREATE DATABASE st_cruiz;
GRANT ALL PRIVILEGES ON st_cruiz.* TO 'cruiz'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Noemie SAMSON
CREATE USER 'nsamson'@'%' IDENTIFIED BY '4d4ka!*cM/PK';
CREATE DATABASE st_nsamson;
GRANT ALL PRIVILEGES ON st_nsamson.* TO 'nsamson'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Myrtille BONHOMME
CREATE USER 'mbonhomme'@'%' IDENTIFIED BY 'B7=+rFv<6s6V';
CREATE DATABASE st_mbonhomme;
GRANT ALL PRIVILEGES ON st_mbonhomme.* TO 'mbonhomme'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Arthur LELEU
CREATE USER 'aleleu'@'%' IDENTIFIED BY 'X<9N4?7mdAvn';
CREATE DATABASE st_aleleu;
GRANT ALL PRIVILEGES ON st_aleleu.* TO 'aleleu'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Emilie BRIERE
CREATE USER 'ebriere'@'%' IDENTIFIED BY 'nY3B<US$rlG5';
CREATE DATABASE st_ebriere;
GRANT ALL PRIVILEGES ON st_ebriere.* TO 'ebriere'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Charlotte AUVRAY
CREATE USER 'cauvray'@'%' IDENTIFIED BY 'g*9pLW:.hUk5';
CREATE DATABASE st_cauvray;
GRANT ALL PRIVILEGES ON st_cauvray.* TO 'cauvray'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Noemie PAGE
CREATE USER 'npage'@'%' IDENTIFIED BY 'B?k*EYk7j94f';
CREATE DATABASE st_npage;
GRANT ALL PRIVILEGES ON st_npage.* TO 'npage'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Malcom PORTIER
CREATE USER 'mportier'@'%' IDENTIFIED BY 'jJ=#sV2&K8$3';
CREATE DATABASE st_mportier;
GRANT ALL PRIVILEGES ON st_mportier.* TO 'mportier'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Arthur VERGNE
CREATE USER 'avergne'@'%' IDENTIFIED BY '8mxl$p8$*WAx';
CREATE DATABASE st_avergne;
GRANT ALL PRIVILEGES ON st_avergne.* TO 'avergne'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Xavier Bertrand DE LA VILLETANAY
CREATE USER 'xbdelavilletanay'@'%' IDENTIFIED BY 'm6p.?VfF!&68';
CREATE DATABASE st_xbdelavilletanay;
GRANT ALL PRIVILEGES ON st_xbdelavilletanay.* TO 'xbdelavilletanay'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Élodie DUPONT-MARTIN
CREATE USER 'édupontmartin'@'%' IDENTIFIED BY 'XiQ6M4:n+%<6';
CREATE DATABASE st_édupontmartin;
GRANT ALL PRIVILEGES ON st_édupontmartin.* TO 'édupontmartin'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Jean-Luc O'CONNOR
CREATE USER 'jloconnor'@'%' IDENTIFIED BY '9*C9Y>zamFca';
CREATE DATABASE st_jloconnor;
GRANT ALL PRIVILEGES ON st_jloconnor.* TO 'jloconnor'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Anaïs DE LA FONTAINE
CREATE USER 'adelafontaine'@'%' IDENTIFIED BY '7SpjLtm>*QQ1';
CREATE DATABASE st_adelafontaine;
GRANT ALL PRIVILEGES ON st_adelafontaine.* TO 'adelafontaine'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Pierre-François LEFÈVRE
CREATE USER 'pflefevre'@'%' IDENTIFIED BY 'kzh9N%Y7-clN';
CREATE DATABASE st_pflefevre;
GRANT ALL PRIVILEGES ON st_pflefevre.* TO 'pflefevre'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Mélanie D'ANGELIS
CREATE USER 'mdangelis'@'%' IDENTIFIED BY 'L2%G-q34Z>bv';
CREATE DATABASE st_mdangelis;
GRANT ALL PRIVILEGES ON st_mdangelis.* TO 'mdangelis'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Sophie VAN DEN BERGHE
CREATE USER 'svandenberghe'@'%' IDENTIFIED BY '2:=RVFx4R53q';
CREATE DATABASE st_svandenberghe;
GRANT ALL PRIVILEGES ON st_svandenberghe.* TO 'svandenberghe'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Michael BERNARD
CREATE USER 'mbernard'@'%' IDENTIFIED BY 'xg2S8?AD=$Uh';
CREATE DATABASE st_mbernard;
GRANT ALL PRIVILEGES ON st_mbernard.* TO 'mbernard'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : François Xavier SAINT-ETIENNE
CREATE USER 'fxsaintetienne'@'%' IDENTIFIED BY '4Vt6$u!=TVst';
CREATE DATABASE st_fxsaintetienne;
GRANT ALL PRIVILEGES ON st_fxsaintetienne.* TO 'fxsaintetienne'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Cécile MÜLLER
CREATE USER 'cmüller'@'%' IDENTIFIED BY '5h#eS&Cct98A';
CREATE DATABASE st_cmüller;
GRANT ALL PRIVILEGES ON st_cmüller.* TO 'cmüller'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Marie-Claire LO'PEZ
CREATE USER 'mclopez'@'%' IDENTIFIED BY 'zTi/N42mf*nP';
CREATE DATABASE st_mclopez;
GRANT ALL PRIVILEGES ON st_mclopez.* TO 'mclopez'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Théo VAN HOUTEN
CREATE USER 'tvanhouten'@'%' IDENTIFIED BY '2pH7>qUy#3mT';
CREATE DATABASE st_tvanhouten;
GRANT ALL PRIVILEGES ON st_tvanhouten.* TO 'tvanhouten'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Léa DUPUIS-MOREAU
CREATE USER 'ldupuismoreau'@'%' IDENTIFIED BY 'EEc5<k=2X>Tt';
CREATE DATABASE st_ldupuismoreau;
GRANT ALL PRIVILEGES ON st_ldupuismoreau.* TO 'ldupuismoreau'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Marc-André LOISELLE
CREATE USER 'maloiselle'@'%' IDENTIFIED BY 'lPK<9bW*!%s5';
CREATE DATABASE st_maloiselle;
GRANT ALL PRIVILEGES ON st_maloiselle.* TO 'maloiselle'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Arthur MICHEL
CREATE USER 'amichel'@'%' IDENTIFIED BY '1v*8&w6ujGJP';
CREATE DATABASE st_amichel;
GRANT ALL PRIVILEGES ON st_amichel.* TO 'amichel'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Sebastien DUPONT
CREATE USER 'sdupont'@'%' IDENTIFIED BY 'U.#f$6P-*iQ4';
CREATE DATABASE st_sdupont;
GRANT ALL PRIVILEGES ON st_sdupont.* TO 'sdupont'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Ines MARCHAL
CREATE USER 'imarchal'@'%' IDENTIFIED BY 'ht#99g3+-K+A';
CREATE DATABASE st_imarchal;
GRANT ALL PRIVILEGES ON st_imarchal.* TO 'imarchal'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Emilie GILLET
CREATE USER 'egillet'@'%' IDENTIFIED BY 'B6:lFpqQ>E91';
CREATE DATABASE st_egillet;
GRANT ALL PRIVILEGES ON st_egillet.* TO 'egillet'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Charlotte GAY
CREATE USER 'cgay'@'%' IDENTIFIED BY '5w:8$xtXz7Lv';
CREATE DATABASE st_cgay;
GRANT ALL PRIVILEGES ON st_cgay.* TO 'cgay'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Noemie CORDIER
CREATE USER 'ncordier'@'%' IDENTIFIED BY 'nE4K!Tvz1*F8';
CREATE DATABASE st_ncordier;
GRANT ALL PRIVILEGES ON st_ncordier.* TO 'ncordier'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Martin BUISSON
CREATE USER 'mbuisson'@'%' IDENTIFIED BY 'F.Ng7fM6?d:c';
CREATE DATABASE st_mbuisson;
GRANT ALL PRIVILEGES ON st_mbuisson.* TO 'mbuisson'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Ines DOS SANTOS
CREATE USER 'idossantos'@'%' IDENTIFIED BY '5U@/8i<nQTJD';
CREATE DATABASE st_idossantos;
GRANT ALL PRIVILEGES ON st_idossantos.* TO 'idossantos'@'%';
FLUSH PRIVILEGES;

-- Utilisateur : Emilie LEVY
CREATE USER 'elevy'@'%' IDENTIFIED BY 'PQul7=esR4/X';
CREATE DATABASE st_elevy;
GRANT ALL PRIVILEGES ON st_elevy.* TO 'elevy'@'%';
FLUSH PRIVILEGES;

