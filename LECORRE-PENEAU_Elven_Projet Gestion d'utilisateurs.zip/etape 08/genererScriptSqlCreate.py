import csv

# Lecture du fichier loginToulouse.csv
with open("C:/Users/elven/OneDrive - Ogec la Joliverie/Projet inter semestre/etape 07/loginToulouse.csv", "r", encoding="utf-8") as f:
    lecteur = csv.reader(f, delimiter=";")
    next(lecteur)  # ignorer l'en-tête

    # Création du fichier SQL
    with open("creerUsersBddAcces.sql", "w", encoding="utf-8") as sql:

        for ligne in lecteur:
            login = ligne[0]
            password = ligne[1]
            lastname = ligne[2]
            firstname = ligne[3]

            #Nom de la base de données
            bdd = "st_" + login

            #Commandes sql
            sql.write(f"-- Utilisateur : {firstname} {lastname}\n")
            sql.write(f"CREATE USER '{login}'@'%' IDENTIFIED BY '{password}';\n")
            sql.write(f"CREATE DATABASE {bdd};\n")
            sql.write(f"GRANT ALL PRIVILEGES ON {bdd}.* TO '{login}'@'%';\n")
            sql.write("FLUSH PRIVILEGES;\n\n")


