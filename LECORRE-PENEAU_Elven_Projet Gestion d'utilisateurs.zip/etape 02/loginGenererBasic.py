
import csv

with open("C:/Users/elven/Desktop/Cours/Projet inter semestre/etape 02/testEntree.csv", "r", encoding="utf-8") as entree, \
     open("testSortie.csv", "w", encoding="utf-8", newline="") as sortie:

    lecteur = csv.reader(entree, delimiter=";")
    ecrivain = csv.writer(sortie, delimiter=";")

    # Écriture de l'en-tête du fichier de sortie
    ecrivain.writerow(["login"])

    # Ignorer l'en-tête du fichier d'entrée
    next(lecteur)

    for ligne in lecteur:
        prenom = ligne[0]
        nom = ligne[1]

        # Prendre la première lettre du prénom
        login = prenom[0] + nom

        # Mise en minuscules
        login = login.lower()

        # Écriture du login dans le fichier de sortie
        ecrivain.writerow([login])


